<div class="conatiner-fluid padding">
	<div class="row text-center padding">
		<div class="col-12">
			<h2>Connect with us</h2>
		</div>
		<div class="col-12 social padding">
			<a href="#"><i class="fab fa-facebook"></i></a>
			<a href="tel:"><i class="fas fa-phone"></i></a>
			<a href="#"><i class="fas fa-envelope"></i></a>
			<a href="https://api.whatsapp.com/send?phone=91"><i class="fab fa-whatsapp"></i></a>
		</div>
	</div>
</div>