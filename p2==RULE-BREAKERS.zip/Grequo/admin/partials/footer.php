<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-center">Grequo-Developed by Bug Busters</p>
            </div>
        </div>
        <!-- Footer Section Ends -->

    </body>
</html>